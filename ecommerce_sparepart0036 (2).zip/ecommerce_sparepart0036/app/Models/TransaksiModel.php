<?php

namespace App\Models;

use CodeIgniter\Model;

class TransaksiModel extends Model
{
    protected $table = 'transaksi'; // Nama tabel transaksi
    protected $primaryKey = 'id_transaksi';
    
    // Kolom yang diperbolehkan untuk diinsert atau diupdate
    protected $allowedFields = [
        'id_pelanggan', 'no_order', 'tgl_order', 'nama_penerima', 
        'provinsi', 'kota', 'alamat', 'kode_pos', 'hp_penerima'
    ];
    
    protected $useTimestamps = false; // Tidak menggunakan kolom timestamp otomatis karena tidak ada di struktur tabel
    
    /**
     * Mengambil data transaksi beserta informasi pelanggan terkait.
     *
     * @return array
     */
    public function getTransaksi()
    {
        return $this->select('transaksi.id_transaksi, transaksi.no_order, transaksi.tgl_order, 
                              transaksi.nama_penerima, transaksi.provinsi, transaksi.kota, 
                              transaksi.alamat, transaksi.kode_pos, transaksi.hp_penerima, 
                              pelanggan.name AS nama_pelanggan')
                    ->join('pelanggan', 'pelanggan.id_pelanggan = transaksi.id_pelanggan')
                    ->findAll();
    }

    /**
     * Menambahkan transaksi baru
     *
     * @param array $data
     * @return bool
     */
    public function createTransaksi($data)
    {
        return $this->insert($data);
    }

    /**
     * Mengambil transaksi berdasarkan ID
     *
     * @param int $id_transaksi
     * @return array
     */
    public function getTransaksiById($id_transaksi)
    {
        return $this->where('id_transaksi', $id_transaksi)->first();
    }
}

<?php

namespace App\Models;

use CodeIgniter\Model;

class GambarBarangModel extends Model
{
    protected $table = 'gambar';
    protected $primaryKey = 'id_gambar';
    protected $allowedFields = ['id_barang', 'gambar', 'ket'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Mengambil semua gambar dengan data barang
     */
    public function getGambarWithBarang()
    {
        return $this->select('gambar.*, barang.nama_barang AS name, barang.deskripsi AS description, barang.harga AS price')
                    ->join('barang', 'barang.id_barang = gambar.id_barang')
                    ->findAll();
    }
}

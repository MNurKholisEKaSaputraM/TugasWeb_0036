<?php

namespace App\Models;

use CodeIgniter\Model;

class AdminModel extends Model
{
    protected $table = 'admin'; // Nama tabel pengguna
    protected $primaryKey = 'id_admin';
    protected $allowedFields = ['nama_admin', 'email', 'password', 'role'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Mengambil data user berdasarkan email.
     *
     * @param string $email
     * @return array|null
     */
    public function getUserByEmail($email)
    {
        return $this->where('email', $email)->first();
    }

    /**
     * Membuat pengguna baru.
     *
     * @param array $data
     * @return bool|int
     */
    public function createUser($data)
    {
        return $this->insert($data);
    }
}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Barang</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Detail Barang</h1>

        <h3>Informasi Barang</h3>
        <table class="table">
            <tr>
                <th>Nama Barang</th>
                <td><?= esc($barang['nama_barang']) ?></td>
            </tr>
            <tr>
                <th>Deskripsi</th>
                <td><?= esc($barang['deskripsi']) ?></td>
            </tr>
            <tr>
                <th>Harga</th>
                <td>Rp<?= number_format($barang['harga'], 0, ',', '.') ?></td>
            </tr>
            <tr>
                <th>Stok</th>
                <td><?= esc($barang['stok']) ?> unit</td>
            </tr>
            <tr>
                <th>Berat</th>
                <td><?= esc($barang['berat']) ?> gram</td>
            </tr>
            <tr>
                <th>Gambar</th>
                <td><img src="<?= base_url('uploads/images/' . $barang['gambar']) ?>" alt="<?= esc($barang['nama_barang']) ?>" width="200"></td>

            </tr>
        </table>

    </div>
</body>
</html>

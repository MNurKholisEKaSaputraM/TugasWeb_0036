<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h3 class="mb-4">Pembayaran</h3>
        <div class="row">
            <!-- Kolom No Rekening Toko -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <strong>No Rekening Toko</strong>
                    </div>
                    <div class="card-body">
                        <p>Silahkan Transfer Uang Ke No Rekening Di Bawah Ini Sebesar :</p>
                        <h3 class="text-primary">Rp <?= number_format($totalPembayaran, 2, ',', '.') ?></h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Bank</th>
                                    <th>No Rekening</th>
                                    <th>Atas Nama</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>BRI</td>
                                    <td>5421-4344-34978</td>
                                    <td>Dhamar Putra Computer (Widodo)</td>
                                </tr>
                                <tr>
                                    <td>BNI</td>
                                    <td>5142-3421-2344</td>
                                    <td>Dhamar Putra Computer (Widodo)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Kolom Upload Bukti Pembayaran -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <strong>Upload Bukti Pembayaran</strong>
                    </div>
                    <div class="card-body">
                        <form action="/pembayaran/upload" method="POST" enctype="multipart/form-data">
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <label for="atas_nama" class="form-label">Atas Nama</label>
                                <input type="text" name="atas_nama" id="atas_nama" class="form-control" placeholder="Atas Nama" required>
                            </div>
                            <div class="mb-3">
                                <label for="nama_bank" class="form-label">Nama Bank</label>
                                <input type="text" name="nama_bank" id="nama_bank" class="form-control" placeholder="Nama Bank" required>
                            </div>
                            <div class="mb-3">
                                <label for="no_rekening" class="form-label">No Rekening</label>
                                <input type="text" name="no_rekening" id="no_rekening" class="form-control" placeholder="No Rekening" required>
                            </div>
                            <div class="mb-3">
                                <label for="bukti_bayar" class="form-label">Bukti Bayar</label>
                                <input type="file" name="bukti_bayar" id="bukti_bayar" class="form-control" required>
                            </div>
                            <div class="d-flex justify-content-between">
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a href="/cart" class="btn btn-success">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dhamar Putra Computer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: #fff;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
        }
        .sidebar .dropdown-menu {
            background-color: #495057;
            border: none;
        }
        .sidebar .dropdown-item {
            color: #fff;
        }
        .sidebar .dropdown-item:hover {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3">
            <h3 class="text-center">Admin Panel</h3>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="<?= base_url('dashboard') ?>" class="nav-link">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                    <li class="nav-item">
    <a href="<?= base_url('/') ?>" class="nav-link">
        <i class="fas fa-shopping-cart"></i> Halaman E-Commerce
    </a>
</li>

                </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-list"></i> Kategori
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a href="<?= base_url('barang') ?>" class="dropdown-item">
                            <i class="fas fa-box"></i> Barang
                        </a>
                        <a href="<?= base_url('pesanan-masuk') ?>" class="dropdown-item">
                            <i class="fas fa-shopping-cart"></i> Pesanan Masuk
                        </a>
                        <a href="<?= base_url('laporan') ?>" class="dropdown-item">
                            <i class="fas fa-chart-line"></i> Laporan
                        </a>
                        <a href="<?= base_url('user') ?>" class="dropdown-item">
                            <i class="fas fa-users"></i> User
                        </a>
                    </div>
                </li>
                <li class="nav-item mt-3">
                    <a href="<?= base_url('auth/logout') ?>" class="btn btn-danger btn-block">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="content">
            <!-- Header -->
            <div class="header d-flex justify-content-between align-items-center">
                <h4>Welcome, <?= esc($user_name) ?>!</h4>
                <span><?= date('l, d F Y') ?></span>
            </div>

            <div class="row mt-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary mb-3">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-users"></i> Pelanggan </h5>
                <p class="card-text"><?= esc($total_pelanggan) ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success mb-3">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-box"></i> Barang</h5>
                <p class="card-text"><?= esc($total_barang) ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning mb-3">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-list"></i> Kategori</h5>
                <p class="card-text"><?= esc($total_kategori) ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-danger mb-3">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-shopping-cart"></i> Pesanan Masuk</h5>
                <p class="card-text"><?= esc($total_transaksi) ?></p>
            </div>
        </div>
    </div>
</div>


            <!-- Recent Activities -->
            <h5 class="mt-4">Recent Activities</h5>
            <table class="table table-striped mt-3">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Activity</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>New product added</td>
                        <td>2024-06-27</td>
                        <td><span class="badge badge-success">Completed</span></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Payment received</td>
                        <td>2024-06-26</td>
                        <td><span class="badge badge-info">Pending</span></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Order shipped</td>
                        <td>2024-06-25</td>
                        <td><span class="badge badge-warning">In Progress</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/js/bootstrap.bundle.min.js"></script>
</body>
</html>

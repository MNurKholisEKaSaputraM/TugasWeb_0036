<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h3 class="mb-4">Cek Out Belanja</h3>
        <form action="/checkout/proses" method="POST">
            <?= csrf_field() ?>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th>Barang</th>
                        <th>Total Harga</th>
                        <th>Berat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart as $item): ?>
                        <tr>
                            <td><?= $item['qty'] ?></td>
                            <td>Rp <?= number_format($item['harga'], 2, ',', '.') ?></td>
                            <td><?= $item['nama_barang'] ?></td>
                            <td>Rp <?= number_format($item['qty'] * $item['harga'], 2, ',', '.') ?></td>
                            <td><?= $item['qty'] * $item['berat'] ?> gr</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="row mb-3">
                <div class="col-md-6">
                    <h5>Tujuan:</h5>
                    <div class="mb-3">
                    <label for="provinsi" class="form-label">Provinsi</label>
                        <select name="provinsi" id="provinsi" class="form-select">
                            <option value="">--Pilih Provinsi--</option>
                            <option value="Aceh">Aceh</option>
                            <option value="Sumatera Utara">Sumatera Utara</option>
                            <option value="Sumatera Barat">Sumatera Barat</option>
                            <option value="Riau">Riau</option>
                            <option value="Kepulauan Riau">Kepulauan Riau</option>
                            <option value="Jambi">Jambi</option>
                            <option value="Sumatera Selatan">Sumatera Selatan</option>
                            <option value="Bangka Belitung">Bangka Belitung</option>
                            <option value="Bengkulu">Bengkulu</option>
                            <option value="Lampung">Lampung</option>
                            <option value="DKI Jakarta">DKI Jakarta</option>
                            <option value="Jawa Barat">Jawa Barat</option>
                            <option value="Jawa Tengah">Jawa Tengah</option>
                            <option value="DI Yogyakarta">DI Yogyakarta</option>
                            <option value="Jawa Timur">Jawa Timur</option>
                            <option value="Banten">Banten</option>
                            <option value="Bali">Bali</option>
                            <option value="Nusa Tenggara Barat">Nusa Tenggara Barat</option>
                            <option value="Nusa Tenggara Timur">Nusa Tenggara Timur</option>
                            <option value="Kalimantan Barat">Kalimantan Barat</option>
                            <option value="Kalimantan Tengah">Kalimantan Tengah</option>
                            <option value="Kalimantan Selatan">Kalimantan Selatan</option>
                            <option value="Kalimantan Timur">Kalimantan Timur</option>
                            <option value="Kalimantan Utara">Kalimantan Utara</option>
                            <option value="Sulawesi Utara">Sulawesi Utara</option>
                            <option value="Sulawesi Tengah">Sulawesi Tengah</option>
                            <option value="Sulawesi Selatan">Sulawesi Selatan</option>
                            <option value="Sulawesi Tenggara">Sulawesi Tenggara</option>
                            <option value="Sulawesi Barat">Sulawesi Barat</option>
                            <option value="Gorontalo">Gorontalo</option>
                            <option value="Maluku">Maluku</option>
                            <option value="Maluku Utara">Maluku Utara</option>
                            <option value="Papua">Papua</option>
                            <option value="Papua Barat">Papua Barat</option>
                            <option value="Papua Selatan">Papua Selatan</option>
                            <option value="Papua Tengah">Papua Tengah</option>
                            <option value="Papua Pegunungan">Papua Pegunungan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="kota" class="form-label">Kota/Kabupaten</label>
                        <input type="text" name="kota" id="kota" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea name="alamat" id="alamat" class="form-control"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="kode_pos" class="form-label">Kode POS</label>
                        <input type="text" name="kode_pos" id="kode_pos" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <h5>Detail Penerima:</h5>
                    <div class="mb-3">
                        <label for="nama_penerima" class="form-label">Nama Penerima</label>
                        <input type="text" name="nama_penerima" id="nama_penerima" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="hp_penerima" class="form-label">HP Penerima</label>
                        <input type="text" name="hp_penerima" id="hp_penerima" class="form-control">
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <strong>Total Berat: <?= $totalBerat ?> gr</strong>
            </div>
            <div class="mb-3">
                <strong>Total Harga: Rp <?= number_format($totalHarga, 2, ',', '.') ?></strong>
            </div>

            <div class="d-flex justify-content-between">
                <a href="/cart" class="btn btn-warning">Kembali ke Keranjang</a>
                <button type="submit" class="btn btn-primary">Proses Checkout</button>
            </div>
        </form>
    </div>
</body>
</html>

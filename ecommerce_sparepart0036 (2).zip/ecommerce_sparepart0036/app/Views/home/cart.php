<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja - Dhamar Putra Computer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Keranjang Belanja</h1>
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Gambar</th>
                    <th>Nama Barang</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $total = 0; ?>
                <?php foreach ($cart as $item): ?>
                    <tr>
                        <td><img src="<?= base_url('uploads/images/' . $item['gambar']) ?>" width="50" alt="<?= esc($item['nama_barang']) ?>"></td>
                        <td><?= esc($item['nama_barang']) ?></td>
                        <td>Rp<?= number_format($item['harga'], 0, ',', '.') ?></td>
                        <td><?= $item['qty'] ?></td>
                        <td>Rp<?= number_format($item['qty'] * $item['harga'], 0, ',', '.') ?></td>
                        <td>
                            <a href="<?= base_url('cart/remove/' . $item['id_barang']) ?>" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                    <?php $total += $item['qty'] * $item['harga']; ?>
                <?php endforeach; ?>
                <tr>
                    <td colspan="4" class="text-right"><strong>Total</strong></td>
                    <td><strong>Rp<?= number_format($total, 0, ',', '.') ?></strong></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        <a href="<?= base_url('/') ?>" class="btn btn-primary">Lanjut Belanja</a>
        <a href="<?= base_url('checkout') ?>" class="btn btn-success">Checkout</a>
    </div>
</body>
</html>

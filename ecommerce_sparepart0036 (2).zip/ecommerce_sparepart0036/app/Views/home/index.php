<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce - Dhamar Putra Computer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Tambahkan ini -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .card {
            border: none;
            transition: transform 0.2s ease-in-out;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card img {
            height: 200px;
            object-fit: cover;
            border-bottom: 2px solid #007bff;
        }
        .badge {
            color: #fff !important; /* Warna teks menjadi putih */
            background-color: #dc3545; /* Warna background merah */
            font-size: 0.8rem; /* Ukuran font lebih kecil */
            vertical-align: top;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Dhamar Putra Computer</a>
            <div>
                <a href="<?= base_url('cart') ?>" class="btn btn-light">
                    <i class="fas fa-shopping-cart"></i> <!-- Ikon keranjang -->
                    <span class="badge"><?= session()->get('cart') ? count(session()->get('cart')) : 0 ?></span>
                </a>
            </div>
        </div>
    </nav>
    <div class="container mt-3">
        <h1 class="text-center mb-4">Produk Kami</h1>
        <div class="row">
            <?php foreach ($barang as $item): ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="<?= base_url('uploads/images/' . $item['gambar']) ?>" class="card-img-top" alt="<?= esc($item['nama_barang']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= esc($item['nama_barang']) ?></h5>
                            <p class="card-text"><strong>Harga:</strong> Rp<?= number_format($item['harga'], 0, ',', '.') ?></p>
                            <p class="card-text"><strong>Stok:</strong> <?= esc($item['stok']) ?></p>
                            <div class="d-flex justify-content-between">
                                <a href="<?= base_url('cart/addToCart/' . $item['id_barang']) ?>" class="btn btn-primary">Tambah ke Keranjang</a>
                                <a href="<?= base_url('barang/detail/' . $item['id_barang']) ?>" class="btn btn-info">Lihat Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/js/bootstrap.bundle.min.js"></script>
</body>
</html>

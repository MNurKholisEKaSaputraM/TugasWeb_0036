<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Barang - Dhamar Putra Computer</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
         body {
            background: linear-gradient(135deg, rgb(238, 238, 238), rgb(0, 0, 0)); /* Gradasi cerah */
            color: #fff;
            font-family: 'Arial', sans-serif;
            overflow-x: hidden;
        }
        .container {
            background: rgba(255, 255, 255, 0.8); /* Latar belakang putih dengan sedikit transparansi */
            padding: 30px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
        }
        h3 {
            color: #f39c12;
            font-weight: 700;
            font-size: 32px;
        }
        .btn-primary {
            background-color: #f39c12;
            border-color: #f39c12;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #e67e22;
            border-color: #e67e22;
        }
        .barang-img {
            max-width: 150px;
            height: auto;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease-in-out;
        }
        .barang-img:hover {
            transform: scale(1.1);
        }
        .modal-img {
            max-width: 100%;
            height: auto;
        }
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }
        .table {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            color: #333;
            font-weight: bold;
        }
        .table thead {
            background-color: #2980b9;
            color: white;
        }
        .table-bordered {
            border: 2px solid #2980b9;
        }
        .btn-sm {
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-warning {
            background-color: #f1c40f;
            border-color: #f1c40f;
        }
        .btn-warning:hover {
            background-color: #f39c12;
            border-color: #f39c12;
        }
        .btn-danger {
            background-color: #e74c3c;
            border-color: #e74c3c;
        }
        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }
        /* Animasi untuk Tabel */
        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        table tbody tr {
            animation: fadeInUp 0.5s ease-in-out;
        }
        .footer-link {
            text-align: center;
            margin-top: 20px;
        }
        .footer-link a {
            color: #007bff;
            font-weight: bold;
            text-decoration: none;
        }
        .footer-link a:hover {
            color: #007bff;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h3 class="text-center mb-4">Daftar Barang Sparepart Komputer</h3>
        <a href="<?= base_url('barang/create') ?>" class="btn btn-primary mb-4">
            <i class="fas fa-plus-circle"></i> Tambah Barang Baru
        </a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Deskripsi</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Berat</th>
                    <th>Gambar</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($barang as $item): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $item['nama_barang'] ?></td>
                        <td><?= $item['deskripsi'] ?></td>
                        <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                        <td><?= $item['stok'] ?></td>
                        <td><?= number_format((float)$item['berat'], 2, ',', '.') ?> gram</td>
                        <td>
                            <img src="<?= base_url('uploads/images/' . $item['gambar']) ?>" 
                                 class="barang-img" 
                                 alt="<?= $item['nama_barang'] ?>" 
                                 data-toggle="modal" 
                                 data-target="#imageModal" 
                                 onclick="showImage('<?= base_url('uploads/images/' . $item['gambar']) ?>')">
                        </td>
                        <td>
                            <a href="<?= base_url('barang/edit/' . $item['id_barang']) ?>" class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="<?= base_url('barang/delete/' . $item['id_barang']) ?>" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash-alt"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="footer-link">
            <p>Ingin menambah barang baru? <a href="<?= base_url('barang/create') ?>">Klik di sini!</a></p>
        </div>
    </div>

    <!-- Modal untuk Menampilkan Gambar -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-transparent border-0">
                <div class="modal-body text-center">
                    <img id="modalImage" class="modal-img" src="" alt="Barang Image">
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/js/bootstrap.bundle.min.js"></script>
</body>
    <script>
        // Fungsi untuk menampilkan gambar di modal
        function showImage(imageUrl) {
            document.getElementById('modalImage').src = imageUrl;
        }
    </script>
</body>
</html>

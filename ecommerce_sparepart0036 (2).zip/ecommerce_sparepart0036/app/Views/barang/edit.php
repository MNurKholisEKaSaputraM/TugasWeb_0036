<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang - Dhamar Putra Computer</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgb(238, 238, 238), rgb(0, 0, 0)); 
            color: #fff;
            font-family: 'Arial', sans-serif;
            overflow-x: hidden;
        }
        .container {
            background: linear-gradient(135deg, rgb(238, 238, 238), rgb(0, 0, 0));  
            padding: 30px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
        }
        h3 {
            color: #fff;
            font-weight: 700;
            font-size: 32px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .form-control {
            border-radius: 5px;
            font-size: 16px;
        }
        .form-control-file {
            border-radius: 5px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group img {
            margin-top: 10px;
            max-width: 150px;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 5px;
        }
        .footer-link {
            text-align: center;
            margin-top: 20px;
        }
        .footer-link a {
            color: #007bff;
            font-weight: bold;
            text-decoration: none;
        }
        .footer-link a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h3 class="text-center mb-4">Edit Barang</h3>
        <form action="<?= base_url('barang/update/' . $barang['id_barang']) ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nama_barang">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" 
                       value="<?= $barang['nama_barang'] ?>" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi Barang</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required><?= $barang['deskripsi'] ?></textarea>
            </div>
            <div class="form-group">
                <label for="harga">Harga Barang</label>
                <input type="number" class="form-control" id="harga" name="harga" 
                       value="<?= $barang['harga'] ?>" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok Barang</label>
                <input type="number" class="form-control" id="stok" name="stok" 
                       value="<?= $barang['stok'] ?>" required>
            </div>
            <div class="form-group">
                <label for="berat">Berat Barang (gram)</label>
                <input type="number" class="form-control" id="berat" name="berat" 
                       value="<?= $barang['berat'] ?>" required>
            </div>
            <div class="form-group">
                <label for="gambar_barang">Gambar Barang</label>
                <input type="file" class="form-control-file" id="gambar_barang" name="gambar_barang">
                <?php if (!empty($barang['gambar_barang'])): ?>
                    <img src="<?= base_url('uploads/images/' . $barang['gambar_barang']) ?>" 
                         alt="Gambar Barang" class="mt-3" style="max-width: 150px;">
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="id_kategori">Kategori</label>
                <select class="form-control" id="id_kategori" name="id_kategori" required>
                    <option value="">Pilih Kategori</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['id_kategori'] ?>"><?= $category['nama_kategori'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Update Barang</button>
        </form>
        <div class="text-center mt-3">
            <a href="<?= base_url('barang') ?>">Kembali ke Daftar Barang</a>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/js/bootstrap.bundle.min.js"></script>
</body>
</html>

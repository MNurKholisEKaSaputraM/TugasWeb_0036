<?php
namespace App\Controllers;

use App\Models\BarangModel;

class HomeController extends BaseController
{
    public function index()
    {
        $barangModel = new BarangModel();
        $data['barang'] = $barangModel->findAll();
        return view('home/index', $data);
    }

    public function viewCart()
    {
        $cart = session()->get('cart') ?? [];
        return view('home/cart', ['cart' => $cart]);
    }

    public function addToCart($id_barang)
    {
        $barangModel = new BarangModel();
        $barang = $barangModel->find($id_barang);

        if ($barang) {
            $cart = session()->get('cart') ?? [];

            $found = false;
            foreach ($cart as &$item) {
                if ($item['id_barang'] == $id_barang) {
                    $item['qty']++;
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                $cart[] = [
                    'id_barang' => $barang['id_barang'],
                    'nama_barang' => $barang['nama_barang'],
                    'harga' => $barang['harga'],
                    'gambar' => $barang['gambar'],
                    'qty' => 1,
                ];
            }

            session()->set('cart', $cart);
        }

        return redirect()->to('/cart');
    }
}

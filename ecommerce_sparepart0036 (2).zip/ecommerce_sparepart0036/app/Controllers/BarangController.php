<?php

namespace App\Controllers;

use App\Models\BarangModel;
use App\Models\KategoriModel;

class BarangController extends BaseController
{
    protected $barangModel;
    protected $kategoriModel;

    public function __construct()
    {
        $this->barangModel = new BarangModel();
        $this->kategoriModel = new KategoriModel();
    }

    /**
     * Menampilkan daftar barang
     */
    public function index()
    {
        $data['barang'] = $this->barangModel->findAll();
        return view('barang/index', $data);
    }

    /**
     * Menampilkan form tambah barang
     */
    public function create()
    {
        $data['categories'] = $this->kategoriModel->findAll();
        return view('barang/create', $data);
    }

    /**
     * Menyimpan barang baru
     */
    public function store()
    {
        $data = $this->request->getPost([
            'nama_barang', 'deskripsi', 'harga', 'stok', 'id_kategori', 'berat',
        ]);

        $gambar = $this->request->getFile('gambar');
        if ($gambar && $gambar->isValid() && !$gambar->hasMoved()) {
            $data['gambar'] = $gambar->getRandomName();
            $gambar->move('uploads/images', $data['gambar']);
        }

        $this->barangModel->save($data);

        return redirect()->to('/barang')->with('success', 'Barang berhasil ditambahkan.');
    }

    /**
     * Menampilkan form edit barang
     */
    public function edit($id)
    {
        // Ambil data barang berdasarkan ID
        $data['barang'] = $this->barangModel->find($id);
        if (!$data['barang']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Barang tidak ditemukan.');
        }

        // Ambil data kategori
        $data['categories'] = $this->kategoriModel->findAll();

        return view('barang/edit', $data);
    }

    /**
     * Memperbarui data barang
     */
    public function update($id)
    {
        // Ambil input dari form
        $data = $this->request->getPost([
            'nama_barang', 'deskripsi', 'harga', 'stok', 'id_kategori', 'berat',
        ]);

        // Cek apakah ada file gambar yang diunggah
        $gambar = $this->request->getFile('gambar');
        if ($gambar && $gambar->isValid() && !$gambar->hasMoved()) {
            // Hapus gambar lama jika ada
            $barangLama = $this->barangModel->find($id);
            if ($barangLama['gambar']) {
                @unlink('uploads/images/' . $barangLama['gambar']);
            }

            // Simpan gambar baru
            $data['gambar'] = $gambar->getRandomName();
            $gambar->move('uploads/images', $data['gambar']);
        }

        $this->barangModel->update($id, $data);

        return redirect()->to('/barang')->with('success', 'Barang berhasil diperbarui.');
    }

    /**
     * Menghapus barang
     */
    public function delete($id)
    {
        // Hapus gambar terkait jika ada
        $barang = $this->barangModel->find($id);
        if ($barang && $barang['gambar']) {
            @unlink('uploads/images/' . $barang['gambar']);
        }

        $this->barangModel->delete($id);

        return redirect()->to('/barang')->with('success', 'Barang berhasil dihapus.');
    }
    public function gambar()
{
    $barangModel = new \App\Models\BarangModel();
    $data['gambarBarang'] = $barangModel->select('id_barang, nama_barang AS name, deskripsi AS description, harga AS price, gambar_barang AS image')
                                       ->findAll();
    return view('barang/gambar', $data);
}

}

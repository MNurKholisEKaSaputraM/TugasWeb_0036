<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class CartController extends Controller
{
    public function index()
    {
        // Ambil data keranjang belanja dari session atau model
        $cart = session()->get('cart') ?? [];
        
        // Kirim data ke view
        return view('/home/cart', ['cart' => $cart]);
    }

    public function remove($id_barang)
    {
        // Ambil data keranjang dari session
        $cart = session()->get('cart') ?? [];

        // Hapus item berdasarkan id_barang
        foreach ($cart as $key => $item) {
            if ($item['id_barang'] == $id_barang) {
                unset($cart[$key]);
                break;
            }
        }

        // Simpan kembali keranjang yang sudah diupdate ke session
        session()->set('cart', $cart);

        // Redirect kembali ke halaman keranjang
        return redirect()->to('/cart');
    }
}

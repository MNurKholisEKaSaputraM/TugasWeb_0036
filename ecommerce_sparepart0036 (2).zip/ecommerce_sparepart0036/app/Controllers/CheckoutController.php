<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BarangModel;
use App\Models\TransaksiModel;

class CheckoutController extends BaseController
{
    public function index()
    {
        // Ambil data keranjang dari session
        $cart = session()->get('cart') ?? [];

        // Instansiasi model barang
        $barangModel = new BarangModel();

        // Menambahkan detail barang (termasuk berat dan harga) ke data keranjang
        foreach ($cart as $key => $item) {
            $barang = $barangModel->find($item['id_barang']);
            if ($barang) {
                $cart[$key]['nama_barang'] = $barang['nama_barang'];
                $cart[$key]['harga'] = $barang['harga'];
                $cart[$key]['berat'] = $barang['berat'];
            }
        }

        // Hitung total berat dan harga
        $totalBerat = 0;
        $totalHarga = 0;
        foreach ($cart as $item) {
            $totalBerat += $item['qty'] * $item['berat'];
            $totalHarga += $item['qty'] * $item['harga'];
        }

        // Kirim data ke view
        $data = [
            'cart' => $cart,
            'totalBerat' => $totalBerat,
            'totalHarga' => $totalHarga,
        ];

        return view('/checkout/index', $data);
    }

    public function proses()
    {
        // Validasi input
        $validation = \Config\Services::validation();
        $validation->setRules([
            'provinsi' => 'required',
            'kota' => 'required',
            'alamat' => 'required',
            'kode_pos' => 'required|numeric',
            'nama_penerima' => 'required',
            'hp_penerima' => 'required|numeric',
        ]);

        if (!$this->validate($validation->getRules())) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        // Ambil data dari input
        $input = $this->request->getPost();

        // Ambil data keranjang dari session
        $cart = session()->get('cart') ?? [];
        if (empty($cart)) {
            return redirect()->back()->with('error', 'Keranjang belanja kosong.');
        }

        // Instansiasi model barang untuk cek stok
        $barangModel = new BarangModel();

        // Validasi stok barang
        foreach ($cart as $item) {
            $barang = $barangModel->find($item['id_barang']);
            if (!$barang || $barang['stok'] < $item['qty']) {
                return redirect()->back()->with('error', 'Stok barang tidak mencukupi: ' . $barang['nama_barang']);
            }
        }

        // Generate nomor order unik
        $noOrder = 'ORD-' . strtoupper(uniqid());

        // Siapkan data untuk tabel transaksi
        $transaksiData = [
            'id_pelanggan' => session()->get('id_pelanggan'), // Ambil dari session
            'no_order' => $noOrder,
            'tgl_order' => date('Y-m-d'),
            'nama_penerima' => $input['nama_penerima'],
            'provinsi' => $input['provinsi'],
            'kota' => $input['kota'],
            'alamat' => $input['alamat'],
            'kode_pos' => $input['kode_pos'],
            'hp_penerima' => $input['hp_penerima'],
            'total_harga' => array_sum(array_column($cart, 'harga')) // Hitung total harga dari keranjang
        ];

        // Simpan data transaksi ke database
        $transaksiModel = new TransaksiModel();
        $transaksiModel->insert($transaksiData);

        // Update stok barang dan reset keranjang
        foreach ($cart as $item) {
            $barang = $barangModel->find($item['id_barang']);
            $barangModel->update($item['id_barang'], [
                'stok' => $barang['stok'] - $item['qty'],
            ]);
        }

        // Hapus data keranjang dari session
        session()->remove('cart');

        // Redirect ke halaman pembayaran dengan nomor order
        return redirect()->to('/checkout/pembayaran/' . $noOrder)->with('message', 'Silakan lanjutkan ke pembayaran.');
    }

    public function pembayaran($noOrder)
    {
        // Ambil detail transaksi berdasarkan nomor order
        $transaksiModel = new TransaksiModel();
        $transaksi = $transaksiModel->where('no_order', $noOrder)->first();

        if (!$transaksi) {
            return redirect()->to('/')->with('error', 'Transaksi tidak ditemukan.');
        }

        // Kirim data transaksi ke view
        $data = [
            'transaksi' => $transaksi,
        ];

        return view('checkout/pembayaran', $data);
    }

    public function sukses()
    {
        return view('checkout_sukses');
    }
}

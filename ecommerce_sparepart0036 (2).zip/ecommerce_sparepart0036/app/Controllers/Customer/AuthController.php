<?php

namespace App\Controllers\Customer;

use App\Models\PelangganModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    protected $pelangganModel;

    public function __construct()
    {
        $this->pelangganModel = new PelangganModel();
    }

    public function login()
    {
        return view('customer/login');
    }

    public function processLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // Check if customer exists
        $pelanggan = $this->pelangganModel->where('email', $email)->first();

        if (!$pelanggan) {
            session()->setFlashdata('error', 'Email not found.');
            return redirect()->back();
        }

        // Verify password
        if (password_verify($password, $pelanggan['password'])) {
            session()->set('pelanggan', $pelanggan);  // Store customer data in session
            return redirect()->to(base_url('customer/dashboard'));  // Redirect to customer dashboard
        } else {
            session()->setFlashdata('error', 'Incorrect password.');
            return redirect()->back();
        }
    }

    public function logout()
    {
        session()->remove('pelanggan');  // Clear customer session
        return redirect()->to(base_url('customer/login'));  // Redirect to login page
    }
}

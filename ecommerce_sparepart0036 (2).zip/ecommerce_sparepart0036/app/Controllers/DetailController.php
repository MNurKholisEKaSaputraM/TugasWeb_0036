<?php

namespace App\Controllers;

use App\Models\BarangModel;

class DetailController extends BaseController
{
    protected $barangModel;

    public function __construct()
    {
        $this->barangModel = new BarangModel();
    }

    public function index($id_barang)
    {
        // Get product details by its ID
        $barang = $this->barangModel->find($id_barang);

        // If the product does not exist, show error
        if (!$barang) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Barang tidak ditemukan');
        }

        // Pass data to the view
        return view('detail/index', [
            'barang' => $barang
        ]);
    }
}

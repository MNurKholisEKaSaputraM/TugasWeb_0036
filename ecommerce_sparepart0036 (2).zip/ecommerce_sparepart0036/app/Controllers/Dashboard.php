<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Dashboard extends BaseController
{
    public function index()
    {
        // Periksa apakah user telah login
        if (!session()->get('is_logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Muat model untuk mengambil data dari database
        $pelangganModel = new \App\Models\PelangganModel();
        $barangModel = new \App\Models\BarangModel();
        $kategoriModel = new \App\Models\KategoriModel();
        $transaksiModel = new \App\Models\TransaksiModel();

        // Hitung jumlah data untuk masing-masing tabel
        $data['total_pelanggan'] = $pelangganModel->countAllResults();
        $data['total_barang'] = $barangModel->countAllResults();
        $data['total_kategori'] = $kategoriModel->countAllResults();
        $data['total_transaksi'] = $transaksiModel->countAllResults();

        // Kirim data user ke view
        $data['user_name'] = session()->get('user_name');

        return view('dashboard/index', $data);
    }
}

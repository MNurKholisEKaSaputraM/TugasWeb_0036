<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PembayaranController extends BaseController
{
    public function upload()
    {
        $validation = $this->validate([
            'atas_nama' => 'required',
            'nama_bank' => 'required',
            'no_rekening' => 'required|numeric',
            'bukti_bayar' => 'uploaded[bukti_bayar]|max_size[bukti_bayar,2048]|is_image[bukti_bayar]|mime_in[bukti_bayar,image/jpg,image/jpeg,image/png]',
        ]);

        if (!$validation) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Proses upload file
        $buktiBayar = $this->request->getFile('bukti_bayar');
        $buktiBayar->move(WRITEPATH . 'uploads/bukti_bayar', $buktiBayar->getName());

        // Simpan data pembayaran ke database (opsional)
        // ...

        return redirect()->to('/pembayaran/sukses')->with('success', 'Bukti pembayaran berhasil diupload.');
    }
}

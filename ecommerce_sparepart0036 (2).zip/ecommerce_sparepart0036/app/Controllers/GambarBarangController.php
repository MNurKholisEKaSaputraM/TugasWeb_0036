<?php

namespace App\Controllers;

use App\Models\GambarBarangModel;
use App\Models\BarangModel;

class GambarBarangController extends BaseController
{
    /**
     * Menampilkan barang beserta gambar
     */
    public function index()
    {
        $gambarBarangModel = new GambarBarangModel();
        $barangModel = new BarangModel();

        // Mengambil semua data gambar dengan data barang terkait
        $gambarBarang = $gambarBarangModel->select('gambar.*, barang.nama_barang AS name, barang.deskripsi AS description, barang.harga AS price')
                                          ->join('barang', 'barang.id_barang = gambar.id_barang')
                                          ->findAll();

        $data['gambarBarang'] = $gambarBarang;

        return view('barang/gambar', $data);
    }
}

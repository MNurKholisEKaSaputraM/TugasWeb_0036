<?php

namespace App\Controllers;

use App\Models\BarangModel;

class Home extends BaseController
{
    protected $barangModel;

    public function __construct()
    {
        $this->barangModel = new BarangModel();
    }

    /**
     * Menampilkan halaman login.
     * 
     * @return string
     */
    public function login()
    {
        // Periksa apakah pengguna sudah login
        if (session()->get('is_logged_in')) {
            return redirect()->to('/home'); // Redirect to main page if logged in
        }

        return view('auth/login'); // Show login view
    }

    /**
     * Menampilkan halaman utama setelah login.
     * 
     * @return string
     */
    public function index()
    {
        // Check if user is logged in
        if (!session()->get('is_logged_in')) {
            return redirect()->to('/'); // Redirect to login page if not logged in
        }

        // Get all barang (products)
        $data = [
            'title' => 'Beranda',
            'barang' => $this->barangModel->findAll(),
            'user_name' => session()->get('user_name'),
        ];

        return view('home/index', $data); // Display home page
    }

    /**
     * Logout pengguna.
     * 
     * @return object
     */
    public function logout()
    {
        session()->destroy(); // Destroy the session
        return redirect()->to('/'); // Redirect to login page after logout
    }
}

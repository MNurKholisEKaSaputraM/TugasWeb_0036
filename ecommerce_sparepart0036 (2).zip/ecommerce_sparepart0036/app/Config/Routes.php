<?php
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Route untuk Login Customer sebagai halaman utama
$routes->get('/', 'Home::login'); // Direct the root URL to the login page

// Main page after login
$routes->get('home', 'Home::index'); // Main content page after login

// Other routes for login, logout, and other actions
$routes->group('customer', function($routes) {
    $routes->get('login', 'Customer\AuthController::login');
    $routes->post('auth/processLogin', 'Customer\AuthController::processLogin');
    $routes->get('logout', 'Customer\AuthController::logout');
});


// Routes untuk register, login, dan logout admin
$routes->get('auth/register', 'Auth::register');
$routes->post('auth/processRegister', 'Auth::processRegister');
$routes->get('auth/login', 'Auth::login');
$routes->post('auth/processLogin', 'Auth::processLogin');
$routes->get('auth/logout', 'Auth::logout');

// Halaman Dashboard Admin
$routes->get('dashboard', 'Dashboard::index');

// Routes lainnya
$routes->get('barang', 'BarangController::index');
$routes->get('barang/create', 'BarangController::create');
$routes->post('barang/store', 'BarangController::store');
$routes->get('barang/edit/(:num)', 'BarangController::edit/$1');
$routes->post('barang/update/(:num)', 'BarangController::update/$1');
$routes->get('barang/delete/(:num)', 'BarangController::delete/$1');

// Routes untuk Customer dan Pesanan
$routes->get('/gambar-barang', 'GambarBarangController::index');
$routes->get('/laporan', 'LaporanController::index');
$routes->get('/setting', 'SettingController::index');
$routes->get('/user', 'UserController::index');
$routes->get('/pesanan-masuk', 'OrdersController::index');

// Checkout
$routes->get('/checkout', 'CheckoutController::index');
$routes->post('/checkout/proses', 'CheckoutController::proses');
$routes->get('/checkout/sukses', 'CheckoutController::sukses');

// pembayran
$routes->get('/checkout/pembayaran/(:segment)', 'CheckoutController::pembayaran/$1');
$routes->post('/pembayaran/upload', 'PembayaranController::upload');
$routes->post('/checkout/konfirmasi', 'Checkout::konfirmasi'); // Untuk proses upload bukti

// Routes untuk keranjang belanja
$routes->group('cart', function ($routes) {
    $routes->get('/', 'CartController::index'); // Menampilkan halaman keranjang
    $routes->get('remove/(:num)', 'CartController::remove/$1'); // Menghapus item dari keranjang
    $routes->get('addToCart/(:num)', 'HomeController::addToCart/$1'); // Menambahkan item ke keranjang
});

// Route untuk detail barang
$routes->get('barang/detail/(:num)', 'DetailController::index/$1');

// Customer login routes should be under `customer`
$routes->group('customer', function($routes) {
    $routes->get('login', 'Customer\AuthController::login');
    $routes->post('auth/processLogin', 'Customer\AuthController::processLogin');
    $routes->get('logout', 'Customer\AuthController::logout');
});

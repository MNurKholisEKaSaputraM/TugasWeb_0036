-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2025 at 06:46 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommercedb_0036`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Admin Utama', 'masell@gmail.com', 'maselkocak', 'superadmin', '2024-12-27 10:16:02', NULL),
(7, 'kocak', 'kocak02@gmail.com', '$2y$10$KlIQXIVlTDKZJgRqoX8UYuKbitdu7H585wroZoJYTMW.UXU8/Ve8W', 'admin', '2024-12-29 21:37:19', '2024-12-30 05:02:20'),
(8, 'MAS EL', 'masel1@gmail.com', '$2y$10$uIZ9IafBA4blEGcNqeyX..mfyHJaOJpikowvYrBu5jP6FfLzEnJn.', 'admin', '2024-12-29 21:44:15', '2024-12-30 05:14:31');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `berat` decimal(10,2) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `id_kategori`, `harga`, `deskripsi`, `stok`, `berat`, `gambar`) VALUES
(1, 'PROCESSOR', 1, 2300000.00, 'intel i5-13400', 28, 20.00, '1735530143_d66114b4e83d25442549.jpg'),
(2, 'PROCESSOR', 1, 4300000.00, 'i7-14700K', 28, 20.00, '1735530727_705c702c351453b4ee7b.jpg'),
(3, 'PROCESSOR', 1, 14200000.00, 'i9-14900K', 20, 20.00, '1735530776_9866d3b0c5a5392a908a.jpg'),
(4, 'PROCESSOR', 1, 2100000.00, 'ryzen 5 5600H', 38, 20.00, '1735530846_ad3a1cc6504fb8401b77.avif'),
(5, 'PROCESSOR', 1, 4800000.00, 'ryzen 7 5800X', 30, 20.00, '1735530922_8ed5a41e1d7a366e365a.jpg'),
(6, 'PROCESSOR', 1, 8800000.00, 'ryzen 9 5900X', 20, 20.00, '1735530958_f5f4d00162eafa9a3940.jpg'),
(7, 'VGA', 2, 9500000.00, 'RTX 3090Ti', 39, 800.00, '1735534211_a21ccffad806af0a779f.jpg'),
(8, 'VGA', 2, 18000000.00, 'RTX 4090', 29, 900.00, '1735534241_4892c4c0bb3bc1c05bf6.jpg'),
(9, 'VGA', 2, 4600000.00, 'RX 6800XT', 47, 800.00, '1735534293_3c9c43399efe5602aa90.jpg'),
(10, 'VGA', 2, 7600000.00, 'RX 7900XT', 40, 800.00, '1735534325_5a8804f5e38f1e649977.jpg'),
(11, 'MOTHERBOARD', 3, 1400000.00, 'asrock B560M', 60, 700.00, '1735534406_39dea91604c969a3c618.png'),
(12, 'MOTHERBOARD', 3, 2400000.00, 'asrock H610M', 50, 700.00, '1735534445_59494b5e34a9eebba4c4.jpg'),
(13, 'MOTHERBOARD', 3, 3200000.00, 'asrock B760M', 50, 700.00, '1735534481_7311224f19be9dbe2225.jpg'),
(14, 'POWER SUPPLY', 4, 600000.00, 'PSU ARMAGEDDON 450W', 20, 500.00, '1735534557_99d95fe7d22096bb615f.jpg'),
(15, 'POWER SUPPLY', 4, 1200000.00, 'PSU COOLER MASTER 750W', 50, 500.00, '1735534610_90d5643bd27cab8573fe.jpg'),
(16, 'POWER SUPPLY', 4, 9000000.00, 'PSU ASUS ROG STRIX 1000W', 20, 900.00, '1735534709_a8fcc721e7d864b20c6c.jpg'),
(17, 'RAM', 5, 500000.00, 'RAM APACER NOX', 30, 10.00, '1735534799_ef7486ca45f17b0d0aae.jpg'),
(18, 'RAM', 5, 600000.00, 'RAM CORSAIR VENGEANCE', 40, 10.00, '1735534838_779ea003e3d55af3a158.webp'),
(19, 'RAM', 5, 800000.00, 'RAM KINGSTON HYPERX', 30, 10.00, '1735534886_2db76429fd1e6c015ca3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gambar`
--

CREATE TABLE `gambar` (
  `id_gambar` int(11) NOT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `ket` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(12) NOT NULL,
  `nama_kategori` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'PROCESSOR'),
(2, 'VGA'),
(3, 'MOTHERBOARD'),
(4, 'POWER SUPPLY'),
(5, 'RAM');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rinci_transaksi`
--

CREATE TABLE `rinci_transaksi` (
  `id_rinci` int(11) NOT NULL,
  `no_order` varchar(50) DEFAULT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(12) NOT NULL,
  `id_pelanggan` int(11) DEFAULT NULL,
  `no_order` varchar(50) DEFAULT NULL,
  `tgl_order` date DEFAULT NULL,
  `nama_penerima` varchar(100) DEFAULT NULL,
  `provinsi` varchar(50) DEFAULT NULL,
  `kota` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kode_pos` varchar(10) DEFAULT NULL,
  `hp_penerima` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pelanggan`, `no_order`, `tgl_order`, `nama_penerima`, `provinsi`, `kota`, `alamat`, `kode_pos`, `hp_penerima`) VALUES
(168, NULL, 'ORD-677F56BEBE1D3', '2025-01-09', 'putra', 'Jateng', 'Pekalongan', 'Kruing', '51126', '0898729752'),
(169, NULL, 'ORD-677F586BEA8FC', '2025-01-09', 'Nur Kholiz', 'Jateng', 'Pekalongan', 'Kruing', '51126', '0888888888888'),
(170, NULL, 'ORD-677F59DB99832', '2025-01-09', 'Naufan', 'Jawa Tengah', 'Kota Pekalongan', 'Sampangan', '51126', '08837246762'),
(171, NULL, 'ORD-677F5BC657888', '2025-01-09', 'Yasnto', 'Sumatera Utara', 'Medan', 'Ashgd', '27334', '0828482324'),
(172, NULL, 'ORD-677F5DBCBE201', '2025-01-09', 'RIN', 'Jawa Barat', 'Bogor', 'Summarecon', '51135', '088274967476'),
(173, NULL, 'ORD-677F5E7A7F4EA', '2025-01-09', 'albert', 'Jawa Barat', 'bekasi', 'kauman', '51142', '0886875664'),
(174, NULL, 'ORD-677F5F3698D9E', '2025-01-09', 'Riff', 'Jawa Tengah', 'Kota Semarang', 'Kauman', '51111', '0828786785665'),
(175, NULL, 'ORD-677F5F70E69A4', '2025-01-09', 'abner', 'Jawa Tengah', 'Temanggung', 'Poncol', '51122', '088274967476'),
(176, NULL, 'ORD-677F5FFD498D9', '2025-01-09', 'Diaz', 'Jawa Tengah', 'Pekalongan', 'Noyontaan', '51124', '0898729752'),
(177, NULL, 'ORD-677F619EBE46F', '2025-01-09', 'kaaaa', 'Jawa Tengah', 'Batang', 'Kauman', '51622', '0886875664'),
(178, NULL, 'ORD-677F62274B6B4', '2025-01-09', 'Dimas', 'Jawa Timur', 'malang', 'Kauman', '51142', '0886875664');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `gambar`
--
ALTER TABLE `gambar`
  ADD PRIMARY KEY (`id_gambar`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `rinci_transaksi`
--
ALTER TABLE `rinci_transaksi`
  ADD PRIMARY KEY (`id_rinci`),
  ADD KEY `no_order` (`no_order`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD UNIQUE KEY `no_order` (`no_order`),
  ADD KEY `fk_transaksi_pelanggan` (`id_pelanggan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `gambar`
--
ALTER TABLE `gambar`
  MODIFY `id_gambar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rinci_transaksi`
--
ALTER TABLE `rinci_transaksi`
  MODIFY `id_rinci` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=179;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`);

--
-- Constraints for table `gambar`
--
ALTER TABLE `gambar`
  ADD CONSTRAINT `gambar_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);

--
-- Constraints for table `rinci_transaksi`
--
ALTER TABLE `rinci_transaksi`
  ADD CONSTRAINT `rinci_transaksi_ibfk_1` FOREIGN KEY (`no_order`) REFERENCES `transaksi` (`no_order`),
  ADD CONSTRAINT `rinci_transaksi_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `fk_transaksi_pelanggan` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

namespace App\Models;

use CodeIgniter\Model;

class TransaksiModel extends Model
{
    protected $table = 'transaksi'; // Nama tabel transaksi
    protected $primaryKey = 'id_transaksi';
    protected $allowedFields = ['user_id', 'order_date', 'status'];
    protected $useTimestamps = true;

    /**
     * Mengambil semua transaksi beserta data user terkait.
     *
     * @return array
     */
    public function getTransaksi()
    {
        return $this->select('transaksi.id_transaksi, transaksi.order_date, transaksi.status, users.name AS username')
            ->join('users', 'users.id = transaksi.user_id')
            ->findAll();
    }
}

<?php

namespace App\Controllers;

use App\Models\TransaksiModel;

class TransaksiController extends BaseController
{
    /**
     * Menampilkan daftar transaksi.
     */
    public function index()
    {
        $transaksiModel = new TransaksiModel();
        $data['transaksi'] = $transaksiModel->getTransaksi(); // Mendapatkan semua transaksi
        return view('transaksi/index', $data); // Pastikan nama view sesuai
    }
}

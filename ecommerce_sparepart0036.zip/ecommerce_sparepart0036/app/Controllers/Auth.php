<?php

namespace App\Controllers;

use App\Models\AdminModel;
use App\Models\UserModel;

class Auth extends BaseController
{
    /**
     * Menampilkan halaman login
     */
    public function login()
    {
        return view('auth/login');
    }

    /**
     * Memproses login pengguna
     */
    public function processLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        if (!$email || !$password) {
            return redirect()->back()->with('error', 'Email dan Password wajib diisi.');
        }

        $userModel = new AdminModel();
        $user = $userModel->where('email', $email)->first();

        if ($user && password_verify($password, $user['password'])) {
            session()->set([
                'user_id' => $user['id_admin'],
                'user_name' => $user['nama_admin'],
                'user_role' => $user['role'],
                'is_logged_in' => true,
            ]);
            return redirect()->to('/dashboard');
        }

        return redirect()->back()->with('error', 'Email atau Password salah.');
    }

    /**
     * Mengakhiri sesi login
     */
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }

    /**
     * Menampilkan halaman registrasi
     */
    public function register()
    {
        return view('auth/register');
    }

    /**
     * Memproses registrasi pengguna baru
     */
    public function processRegister()
    {
        $name = $this->request->getPost('name');
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $confirmPassword = $this->request->getPost('confirm_password');

        if (!$name || !$email || !$password || !$confirmPassword) {
            return redirect()->back()->with('error', 'Semua field wajib diisi.');
        }

        if ($password !== $confirmPassword) {
            return redirect()->back()->with('error', 'Password dan Konfirmasi Password tidak sama.');
        }

        $userModel = new AdminModel();

        if ($userModel->where('email', $email)->first()) {
            return redirect()->back()->with('error', 'Email sudah terdaftar.');
        }

        $userModel->save([
            'nama_admin' => $name, // Ganti 'name' menjadi 'nama_admin'
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => 'customer',
        ]);
        

        return redirect()->to('/auth/login')->with('success', 'Registrasi berhasil, silakan login.');
    }
}

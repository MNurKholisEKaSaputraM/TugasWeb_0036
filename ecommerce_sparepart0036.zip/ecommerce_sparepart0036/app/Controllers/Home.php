<?php

namespace App\Controllers;

use App\Models\BarangModel;

class Home extends BaseController
{
    protected $barangModel;

    public function __construct()
    {
        // Inisialisasi model barang
        $this->barangModel = new BarangModel();
    }

    /**
     * Menampilkan halaman utama.
     * 
     * @return string|object
     */
    public function index()
    {
        // Periksa apakah pengguna sudah login
        if (!session()->get('is_logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil data barang untuk ditampilkan di halaman utama
        $data = [
            'title' => 'Beranda',
            'barang' => $this->barangModel->findAll(), // Mengambil semua barang
            'user_name' => session()->get('user_name'), // Nama pengguna yang login
        ];

        return view('home/index', $data);
    }

    /**
     * Menampilkan halaman login.
     * 
     * @return string
     */
    public function login(): string
    {
        // Periksa apakah pengguna sudah login
        if (session()->get('is_logged_in')) {
            return redirect()->to('/home');
        }

        return view('auth/login');
    }

    /**
     * Logout pengguna.
     * 
     * @return object
     */
    public function logout()
    {
        // Menghancurkan session
        session()->destroy();

        return redirect()->to('/auth/login')->with('success', 'Anda telah logout.');
    }
}

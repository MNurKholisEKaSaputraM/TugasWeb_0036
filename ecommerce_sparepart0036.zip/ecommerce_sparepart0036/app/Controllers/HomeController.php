<?php

namespace App\Controllers;

use App\Models\BarangModel;

class HomeController extends BaseController
{
    public function index()
    {
        // Ambil data barang dari database
        $barangModel = new BarangModel();
        $data['barang'] = $barangModel->findAll(); // Semua barang ditampilkan

        return view('home/index', $data);
    }

    public function viewCart()
    {
        // Ambil data keranjang dari session
        $cart = session()->get('cart') ?? [];
        
        // Kirim data ke view
        return view('/home/cart', ['cart' => $cart]);
    }

    public function addToCart($id_barang)
    {
        // Cek apakah barang ada di database
        $barangModel = new \App\Models\BarangModel();
        $barang = $barangModel->find($id_barang);
        
        if ($barang) {
            // Ambil data keranjang dari session
            $cart = session()->get('cart') ?? [];
    
            // Cek apakah item sudah ada di keranjang
            $found = false;
            foreach ($cart as &$item) {
                if ($item['id_barang'] == $id_barang) {
                    $item['qty']++;
                    $found = true;
                    break;
                }
            }
    
            // Jika barang belum ada di keranjang, tambahkan
            if (!$found) {
                $cart[] = [
                    'id_barang' => $barang['id_barang'],
                    'nama_barang' => $barang['nama_barang'],
                    'harga' => $barang['harga'],
                    'gambar' => $barang['gambar'],
                    'qty' => 1,
                ];
            }
    
            // Simpan keranjang kembali ke session
            session()->set('cart', $cart);
        }
    
        // Redirect kembali ke halaman keranjang
        return redirect()->to('/cart');
    }
    
}

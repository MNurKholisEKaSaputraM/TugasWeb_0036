<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Dhamar Putra Computer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Checkout</h1>
        <form action="<?= base_url('checkout/process') ?>" method="post">
            <div class="form-group">
                <label for="nama">Nama Penerima</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="hp">Nomor HP</label>
                <input type="text" class="form-control" id="hp" name="hp" required>
            </div>
            <button type="submit" class="btn btn-success btn-block">Proses Checkout</button>
        </form>
    </div>
</body>
</html>

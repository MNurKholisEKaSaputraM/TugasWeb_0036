<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Halaman Utama
$routes->get('/', 'Home::index'); // Halaman utama

$routes->get('auth/register', 'Auth::register');
$routes->post('auth/processRegister', 'Auth::processRegister');
$routes->get('auth/login', 'Auth::login');
$routes->post('auth/processLogin', 'Auth::processLogin');
$routes->get('auth/logout', 'Auth::logout');
$routes->get('dashboard', 'Dashboard::index');

$routes->get('/gambar-barang', 'GambarBarangController::index');
$routes->get('/laporan', 'LaporanController::index');
$routes->get('/setting', 'SettingController::index');
$routes->get('/user', 'UserController::index');

$routes->get('barang', 'BarangController::index');
$routes->get('barang/create', 'BarangController::create');
$routes->post('barang/store', 'BarangController::store');
$routes->get('barang/edit/(:num)', 'BarangController::edit/$1');
$routes->post('barang/update/(:num)', 'BarangController::update/$1');
$routes->get('barang/delete/(:num)', 'BarangController::delete/$1');

$routes->get('gambar-barang', 'GambarBarangController::index');

$routes->get('/pesanan-masuk', 'OrdersController::index');

// Halaman Utama
$routes->get('/', 'HomeController::index'); // Halaman utama
$routes->get('cart', 'HomeController::viewCart'); // Halaman keranjang
$routes->get('cart/remove/(:num)', 'CartController::remove/$1'); // Hapus dari keranjang
$routes->get('cart/addToCart/(:num)', 'HomeController::addToCart/$1'); // Tambah ke keranjang
$routes->get('checkout', 'CheckoutController::index'); // Halaman checkout
$routes->post('checkout/process', 'CheckoutController::process'); // Proses checkout




$routes->get('admin', 'Dashboard::index'); // Halaman dashboard admin













